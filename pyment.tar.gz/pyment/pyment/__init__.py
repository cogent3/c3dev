from .pyment import PyComment, __version__, __copyright__, __author__, __licence__

name = "pyment"

__all__ = ['PyComment', '__version__', '__copyright__', '__author__', '__licence__']
