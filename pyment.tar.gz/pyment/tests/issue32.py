def hello_world(a=22, b='hello'):
  return 42