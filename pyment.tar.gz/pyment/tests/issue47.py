def func():
    """Description
    in two lines

    """
    pass


