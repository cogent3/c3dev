def func(param): # some comment
    """some docstring"""
    pass


