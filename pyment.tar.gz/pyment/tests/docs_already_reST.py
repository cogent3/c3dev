def func1(param1):
    """Function 1
    with 1 param

    :param param1: 1st parameter
    :type param1: type
    :returns: None

    """
    return None


def func2(param1, param2):
    """Function 2
    with 2 params

    :param param1: 1st parameter
    :type param1: type
    :param param2: 2nd parameter

    """
    pass


