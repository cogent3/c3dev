class Issue22(object):
    """Test class for issue 22"""

    def __init__(self, param1):
        pass
