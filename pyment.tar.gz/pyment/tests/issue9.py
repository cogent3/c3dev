def func(p):
    """
    :param p: blabla
    :type p: ptype
    :return: smthg
    :rtype: ret type
    """
    pass
