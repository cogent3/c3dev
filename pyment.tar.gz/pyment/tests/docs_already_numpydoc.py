def func1(param1):
    """Function 1
    with 1 param

    Parameters
    ----------
    param1 : type
        1st parameter

    Returns
    -------
    string
        a message

    Raises
    ------
    KeyError
        when a key error
    """
    return "huh"


def func2(param1, param2):
    """Function 2
    with 2 params

    Parameters
    ----------
    param1 : type
        1st parameter
    param2 :
        2nd parameter

    Returns
    -------

    """
    pass


