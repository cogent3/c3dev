def func1(param1=[1, None, "hehe"]):
    pass


def func2(param1=(1, None, "hehe")):
    pass


def func3(param1={0: 1, "a": None}):
    pass

