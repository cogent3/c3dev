def foo():
    """Bar bar bar.

    Args:

    Returns:

    Raises:
      test

    """
    pass
