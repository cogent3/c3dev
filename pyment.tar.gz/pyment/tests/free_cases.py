def func1():
    """Function 1 no parameter"""
    pass

