def func(a, b):
    """desc

    :param a: 
    :param b: 

    """
    pass

def func(a, b):
    """desc

    :param a: 
    :type a: 
    :param b: 
    :type b: 

    """
    pass

def func(a, b):
    """desc

    :param a: 
    :type a: str
    :param b: 
    :type b: str

    """
    pass

def func(a, b):
    """desc

    :param a: 
    :type a: str
    :param b: 
    :type b: 

    """
    pass

def func(a, b):
    """desc

    :param a: desc a
    :param b: 

    """
    pass

def func(a, b):
    """desc

    :param b: 
    :param a: desc a

    """
    pass

def func(a, b):
    """desc

    :param a: 
    :param b: desc b

    """
    pass

def func(a, b, c):
    """desc

    :param a: 
    :param b: 
    :param c: 

    """
    pass

def func(a, b, c):
    """desc

    :param a: 
    :param b: desc b
    :param c: 

    """
    pass

def func(a, b, c):
    """desc

    :param a: desc a
    :param b: 
    :param c: 

    """
    pass

def func(a, b, c):
    """desc

    :param a: desc a
    :param b: 
    :param c: desc c

    """
    pass

