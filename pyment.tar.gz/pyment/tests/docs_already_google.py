def func1(param1):
    """Function 1
    with 1 param

    Args:
      param1(type): 1st parameter

    Returns:
      None

    Raises:
      Exception: an exception

    """
    return None


def func2(param1, param2):
    """Function 2
    with 2 params

    Args:
      param1(type): 1st parameter
      param2: 2nd parameter

    Returns:

    """
    pass


