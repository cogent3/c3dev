.. Pyment documentation master file, created by
   sphinx-quickstart on Wed Sep 27 21:39:14 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Pyment's documentation!
==================================

.. toctree::
   :maxdepth: 1

   pyment

   pyment_doc

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
